/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type ItemCategory =
  | 'Dairy'
  | 'Vegetables'
  | 'Leafy Greens'
  | 'Fruits'
  | 'Grains & Flours'
  | 'Pulses & Dal'
  | 'Bakery & Bread'
  | 'Spices & Condiments'
  | 'Snacks & Packaged'
  | 'Eggs, Meat & Poultry'
  | 'Beverages'
  | 'Cooked Leftovers'
  | 'Other';

export type StorageLocation = 'fridge' | 'pantry' | 'freezer';

export type ItemStatus = 'active' | 'used' | 'expired';

export type DietType = 'veg' | 'egg' | 'non-veg';

export type OperationScale = 'household' | 'restaurant' | 'enterprise';

export interface InventoryItem {
  id: string;
  name: string;
  category: ItemCategory;
  quantity: number;
  unit: string;
  purchaseDate: string; // YYYY-MM-DD
  estimatedExpiryDate: string; // YYYY-MM-DD
  printedExpiryDate?: string | null;
  storage: StorageLocation;
  price: number | null; // In INR (₹)
  status: ItemStatus;
  originalQuantity?: number | null;
  savedMoney?: number | null;
  usedAt?: string | null;
  source: 'barcode' | 'receipt' | 'manual';
  barcode?: string | null;
  notes?: string | null;
  imageUrl?: string | null;
  // Commercial / Restaurant / Enterprise parameters
  batchCode?: string | null;
  supplierName?: string | null;
  parLevel?: number | null;
  branchZone?: string | null;
  createdAt?: string;
  updatedAt?: string;
}

export type PortionPreset = 'little' | 'half' | 'most' | 'all' | 'custom';

export interface UseItemPayload {
  portion?: number; // 0.25, 0.5, 0.75, 1.0 or custom 0..1
  usedQuantity?: number; // exact amount used
  usedPortionName?: string; // e.g. "A Little (25%)", "Half (50%)"
}

export interface RecipeIngredient {
  name: string;
  amount: string;
}

export interface CustomRecipeIngredient {
  itemId?: string; // ID of inventory item if chosen from pantry
  name: string;
  portionUsed?: number; // 0.25, 0.5, 0.75, 1.0
  quantityUsed?: number; // exact amount deducted
  unit?: string;
  amountText?: string;
  isPantryStaple?: boolean; // spices, salt, oil, etc.
}

export interface CustomRecipe {
  id: string;
  title: string;
  description: string;
  image?: string;
  timeMinutes: number;
  servings: number;
  difficulty: 'Quick' | 'Easy' | 'Medium';
  diet: DietType;
  cuisine: string;
  ingredients: CustomRecipeIngredient[];
  instructions: string[];
  notes?: string;
  cookedCount?: number;
  lastCookedAt?: string;
  createdAt?: string;
  updatedAt?: string;
  source: 'custom';
}

export interface Recipe {
  id: string;
  title: string;
  description: string;
  image: string;
  timeMinutes: number;
  servings: number;
  difficulty: 'Quick' | 'Easy' | 'Medium';
  diet: DietType;
  cuisine: string;
  usedExpiringItems: string[];
  allIngredients: RecipeIngredient[];
  instructions: string[];
  source?: 'gemini' | 'local' | 'custom';
  cookedCount?: number;
  lastCookedAt?: string;
}

export interface UserPreferences {
  operationScale: OperationScale;
  organizationName?: string;
  branchLocation?: string;
  wasteBudgetRs?: number;
  scaleConfigured?: boolean;
  diet: DietType;
  reminderLeadDays: number; // 1, 2, 3, or 7
  morningDigestEnabled: boolean;
  morningDigestTime: string;
  defaultStorage: StorageLocation;
}

export interface InventoryStats {
  totalLogged: number;
  activeCount: number;
  usedCount: number;
  expiredCount: number;
  urgentCount: number; // Expiring in <= 2 days
  freshCount: number;
  moneySavedRs: number;
  moneyWastedRs: number;
  unpricedUsedCount: number;
  unpricedExpiredCount: number;
  savingPercentage: number;
  zeroWasteStreakDays: number;
  totalScansLogged: number;
  lowStockCount?: number;
  totalActiveValueRs?: number;
  valueAtRiskRs?: number;
}

export interface ReceiptParsedItem {
  id: string;
  name: string;
  category: ItemCategory;
  quantity: number;
  unit: string;
  price: number | null;
  estimatedExpiryDays: number;
  storage: StorageLocation;
  selected?: boolean;
  originalText?: string;
}

export interface DbInfo {
  engine: string;
  filePath: string;
  itemsCount: number;
  activeCount: number;
  usedCount: number;
  recipesCount?: number;
}

export type RestockReason = 'completed' | 'low-stock' | 'expired' | 'manual';

export interface RestockItem {
  id: string;
  name: string;
  category: ItemCategory;
  targetQuantity: number;
  unit: string;
  storage: StorageLocation;
  estimatedPrice: number | null;
  supplierName?: string | null;
  branchZone?: string | null;
  parLevel?: number | null;
  sourceItemId?: string | null;
  reason: RestockReason;
  priority: 'urgent' | 'normal';
  checked: boolean;
  status: 'pending' | 'stocked';
  notes?: string | null;
  createdAt?: string;
  updatedAt?: string;
}

export interface StockFromRestockPayload {
  quantity?: number;
  unit?: string;
  price?: number | null;
  storage?: StorageLocation;
  estimatedExpiryDate?: string;
  batchCode?: string | null;
  supplierName?: string | null;
  parLevel?: number | null;
  branchZone?: string | null;
}

export type MealSlot = 'breakfast' | 'lunch' | 'dinner';

export interface MealPlanEntry {
  id: string;
  dayOfWeek: string; // 'Mon' | 'Tue' | 'Wed' | 'Thu' | 'Fri' | 'Sat' | 'Sun'
  slot: MealSlot;
  recipeId?: string | null;
  recipeTitle: string;
  servings: number;
  ingredients: string[];
  notes?: string | null;
  createdAt?: string;
  updatedAt?: string;
}

export interface ActivityLogEntry {
  id: string;
  action: string;
  itemName: string;
  details: string;
  timestamp: string;
}

export interface Supplier {
  id: string;
  name: string;
  contactName?: string | null;
  phone?: string | null;
  whatsapp?: string | null;
  email?: string | null;
  categories?: string | null;
  leadTimeDays: number;
  paymentTerms?: string | null;
  notes?: string | null;
  createdAt?: string;
  updatedAt?: string;
}

export type StorageZoneType = 'fridge' | 'freezer' | 'pantry' | 'hot-hold';

export interface StorageLog {
  id: string;
  zoneName: string;
  zoneType: StorageZoneType;
  temperatureC: number;
  humidityPct?: number | null;
  status: 'pass' | 'warning' | 'alert';
  checkedBy?: string | null;
  branchZone?: string | null;
  notes?: string | null;
  loggedAt: string;
}

export type ChecklistCategory = 'opening' | 'closing' | 'hygiene' | 'handover';

export interface ChecklistItem {
  id: string;
  title: string;
  category: ChecklistCategory;
  completed: boolean;
  completedAt?: string | null;
  assignedTo?: string | null;
  notes?: string | null;
  createdAt?: string;
  updatedAt?: string;
}

export interface TransferItemPayload {
  quantity: number;
  targetStorage: StorageLocation;
  targetBranchZone?: string | null;
  notes?: string | null;
}

export interface StocktakeEntryPayload {
  itemId: string;
  actualQuantity: number;
  zeroDisposition?: 'used' | 'expired';
  addShortageToBuyList?: boolean;
}

export interface StocktakeResult {
  adjustedCount: number;
  shortageCount: number;
  totalVarianceRs: number;
  items: InventoryItem[];
  restockList: RestockItem[];
}

export type WasteReason =
  | 'expired'
  | 'overproduction'
  | 'trim-loss'
  | 'cold-chain'
  | 'damaged-delivery'
  | 'plate-waste'
  | 'other';

export interface WasteLogEntry {
  id: string;
  itemId?: string | null;
  itemName: string;
  category: string;
  quantityWasted: number;
  unit: string;
  lossRs: number;
  reason: WasteReason;
  loggedBy?: string | null;
  branchZone?: string | null;
  notes?: string | null;
  loggedAt: string;
}

export interface LogWastePayload {
  itemId?: string | null;
  itemName: string;
  category: string;
  quantityWasted: number;
  unit: string;
  lossRs: number;
  reason: WasteReason;
  loggedBy?: string | null;
  branchZone?: string | null;
  notes?: string | null;
}

export type InvoiceStatus = 'paid' | 'pending' | 'overdue';

export interface PurchaseInvoice {
  id: string;
  invoiceNumber: string;
  supplierName: string;
  invoiceDate: string; // YYYY-MM-DD
  dueDate?: string | null;
  amountRs: number;
  category: string;
  paymentStatus: InvoiceStatus;
  itemsCount?: number | null;
  branchZone?: string | null;
  notes?: string | null;
  createdAt?: string;
  updatedAt?: string;
}
